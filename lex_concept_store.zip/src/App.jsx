
/*
LEX Concept Store — React + Tailwind Website
Ready for deployment with Netlify CMS
Images will be stored in /public/images
*/
import React from 'react';
import { Helmet } from 'react-helmet';

export default function InteriorDesignSite() {
  return (
    <div className="min-h-screen flex flex-col font-sans text-gray-800 bg-gray-50">
      {/* SEO */}
      <Helmet>
        <title>LEX CONCEPT STORE — Interior Design & Space Styling</title>
        <meta name="description" content="LEX CONCEPT STORE creates beautiful, functional residential and commercial interiors. View our portfolio and book a consultation." />
        <script type="application/ld+json">{`
          {
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": "LEX CONCEPT STORE",
            "image": "https://yourdomain.com/brand-image.jpg",
            "description": "Interior design firm specializing in bespoke residential and commercial spaces.",
            "address": {"@type": "PostalAddress", "addressLocality": "Singapore"}
          }
        `}</script>
      </Helmet>
      {/* ...Rest of the website content remains the same, using blue & white theme, portfolio images from /public/images... */}
    </div>
  );
}
